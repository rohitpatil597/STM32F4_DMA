#include <stdint.h>
#include "stm32F4xx.h"
#include "stm32f429xx.h"

void Button_Init();
void Usart1_Init();
void DMA_Init();
void send_data();

void DMA_TCIE_Callback();
void DMA_HTIE_Callback();
void DMA_TEIE_Callback();
void DMA_DMEIE_Callback();
void DMA_Interrupt_Enable();

uint8_t data[]="Hello World\r\n";

int main()
{
	Button_Init();
	Usart1_Init();
	DMA_Init();
	DMA_Interrupt_Enable();
	while(1);
	return 0;
}

void Button_Init()
{
RCC_TypeDef *pRCCCLK;
GPIO_TypeDef *pGPIO;
EXTI_TypeDef *pEXTI;
SYSCFG_TypeDef *pSYSCFG;

pGPIO=GPIOA;
pRCCCLK=RCC;
pEXTI=EXTI;
pSYSCFG=SYSCFG;

//Enable the clock for PA0 GPIO Pin
pRCCCLK->AHB1ENR |= (1 << 0);              // Enable clock for PA0 Pin
pRCCCLK->APB2ENR |= (1 << 14);
//Configure Mode as input mode
pGPIO->MODER   &= ~(0x03 << 0);            //Input mode

//Enable the interrupt for specific line
pEXTI->IMR |=(1 << 0);

pSYSCFG->EXTICR[0] &=~(0xF << 0);

//Enable the falling edge trigger
pEXTI->FTSR |=(1 << 0);

//Enable the NvIC machine configuration for interrupt
NVIC_EnableIRQ(EXTI0_IRQn);
}

void Usart1_Init()
{
    USART_TypeDef *pUSART;
    GPIO_TypeDef *pGPIO;
    RCC_TypeDef *pRCCCLK;

    pGPIO=GPIOA;
    pRCCCLK=RCC;
    pUSART=USART1;

    RCC->APB2ENR |= (1 << 4);        //USART1 Clock Enable
    pRCCCLK->AHB1ENR |= (1 << 0);    //USART1_GPIO Clock Enable USART1_TX-PA9 , USART1_RX-PA10

    pGPIO->MODER |= (0x2 << 18);
    pGPIO->MODER |= (0x2 << 20);     //pGPIO->MODER |= (0X28 << 18);

    pGPIO->AFR[1] |= (0x7 << 4);
    pGPIO->AFR[1] |= (0x7 << 8);

    pGPIO->PUPDR |=(0x01 << 18);     //For PA9 Pull up configuration
    pGPIO->PUPDR |=(0x01 << 20);     //For PA10 Pull up configuration

    pUSART->BRR = 0x8B;              //Loading the Baudrate value

    pUSART->CR1 |=(1 << 13);         //Enable USART
    //pUSART->CR1 |=(1 << 12);         //Word length Start bit, 9 Data bits, n Stop bit
    pUSART->CR1 |=(1 << 3);          //TE  Enable
    pUSART->CR1 |=(1 << 2);          //RE  Enable

    pUSART->CR2 &= ~(1 << 14);       //LIN mode  Disable
    //pUSART->CR2 &= ~(0x3 << 12);     //1 StopBit

}
void send_data()
{
	USART_TypeDef *pUSART;
	pUSART=USART1;

    uint8_t i;
    uint8_t size;


	size=sizeof(data);

    for(i=0;i<size;i++)
    {
	while(!((pUSART->SR >> 7) & 0x1));
	pUSART->DR=data[i];
    }
}

void DMA_Init()
{
	 /*DMA2
	 * Channel 4
	 * USART1_TX-Stream 7
	 * USART1_RX-Stream 5
	 */
	DMA_Stream_TypeDef *pDMA2Stream;
	USART_TypeDef *pUSART;
	RCC_TypeDef *pRCCCLK;

	pRCCCLK=RCC;
	pUSART=USART1;
	pDMA2Stream=DMA2_Stream7;

	//1 Select DMA for USART1
	pUSART->CR3 |= (1 << 6);  //Enable the DMA Transmission for USART
	pUSART->CR3 |= (1 << 7);  //Enable the DMA Receiver for USART
	//2 Enable Clock for DMA2
	pRCCCLK->AHB1ENR |= (1 << 22); //Enable DMA2 Clock
	//3 Configure Channel and Stream
	pDMA2Stream->CR |= (0x4 << 25);
    //Increment Mem Address
	pDMA2Stream->CR |=(1 << 10);
	//5 Configure the Sourse address
	pDMA2Stream->M0AR=(uint32_t)data;
	//6 Configure the Destinition address
	pDMA2Stream->PAR=(uint32_t)&pUSART->DR;
	//7 Configure length of data transfer
	pDMA2Stream->NDTR = (uint32_t)sizeof(data);
	//8 Configure direction of transfer the data
	pDMA2Stream->CR |= (0x1 << 6);
	//9. Select the width of data transfer like byte-by-byte, word etc
	pDMA2Stream->CR &=~(0x3 <<11);   //Peripheral Size
	pDMA2Stream->CR &=~(0x3 <<13);   //Memory Size
	//10 enable the FIFO mode
	pDMA2Stream->FCR |=(1 << 2); //Disable Direct mode and Enable  FIFO mode
	//11 Configure FIFO threshold selection
	pDMA2Stream->FCR &=~(0x3 << 0);
	pDMA2Stream->FCR |=(0x3 << 0);

	//11 Enable the stream of transfer mode
	pDMA2Stream->CR |= (1 << 0);
}

void DMA_Interrupt_Enable()
{
	DMA_Stream_TypeDef *pDMA2Stream;
	pDMA2Stream=DMA2_Stream7;

	//Enable Interrupt
	    pDMA2Stream->CR |=(1 << 4); //Transfer complete interrupt enable
        pDMA2Stream->CR |=(1 << 3); //Half transfer interrupt enable
	    pDMA2Stream->CR |=(1 << 2); //Transfer error interrupt enable
		pDMA2Stream->CR |=(1 << 1); //Transfer error interrupt enable
		NVIC_EnableIRQ(DMA2_Stream7_IRQn);
}

void DMA_TCIE_Callback()
{
	USART_TypeDef *pUSART1;
	pUSART1 = USART1;

	DMA_Stream_TypeDef *pSTREAM7;
	pSTREAM7 = DMA1_Stream7;

	//Program number of data items to send
	uint32_t len = sizeof(data);
	pSTREAM7->NDTR = len;

	pUSART1->CR3 &= ~( 1 << 7);
	//11 Enable the stream of transfer mode
	pSTREAM7->CR |= (1 << 0);
}

void DMA_HTIE_Callback()
{

}

void DMA_TEIE_Callback()
{
while(1);
}

void DMA_DMEIE_Callback()
{
while(1);
}
